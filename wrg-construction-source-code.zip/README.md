
## Setup Instructions
1. Download and unzip the project files.
2. Open the terminal and navigate to the project folder.
3. Run `npm install` to install the necessary dependencies.
4. Run `npm run dev` to start the development server.
